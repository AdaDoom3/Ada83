-- C87B02A.ADA
    
-- CHECK THAT OVERLOADING RESOLUTION USES THE RULE THAT:
--
-- IN A CONSTANT DECLARATION, THE TYPE OF THE INITIALIZATION
-- EXPRESSION MUST MATCH THE CONSTANT'S EXPLICIT TYPEMARK.
--      
-- THE FOUR KINDS OF EXPRESSIONS TESTED HERE ARE:
-- 
--    (A): A CALL TO AN OVERLOADED FUNCTION.
--    (B): AN OVERLOADED OPERATOR SYMBOL.
--    (C): AN OVERLOADED (INFIX) OPERATOR.
--    (D): AN OVERLOADED ENUMERATION LITERAL.
  
-- TRH  17 JUNE 82
  
WITH REPORT; USE REPORT;
   
PROCEDURE C87B02A IS
  
     TYPE WHOLE  IS NEW INTEGER RANGE 0..INTEGER'LAST;
     TYPE CITRUS IS (LEMON, LIME, ORANGE);
     TYPE HUE    IS (RED, ORANGE, YELLOW);
     
     FUNCTION F1 (X, Y : INTEGER) RETURN INTEGER IS
     BEGIN
          RETURN -1;
     END F1;

     FUNCTION F1 (X, Y : WHOLE) RETURN WHOLE IS
     BEGIN
          RETURN 0;
     END F1;
    
     FUNCTION F1 (X, Y : INTEGER) RETURN HUE IS
     BEGIN
          RETURN ORANGE;
     END F1;

     FUNCTION F1 (X, Y : INTEGER) RETURN CITRUS IS
     BEGIN
          RETURN ORANGE;
     END F1;
   
BEGIN
     TEST ("C87B02A","OVERLOADED INITIALIZATION EXPRESSIONS" &
          " IN CONSTANT DECLARATIONS");
     DECLARE

          FUNCTION "*" (X, Y : INTEGER) RETURN INTEGER
               RENAMES F1;
    
          FUNCTION "*" (X, Y : WHOLE)   RETURN WHOLE
               RENAMES F1;
     
          FUNCTION "*" (X, Y : INTEGER) RETURN HUE
               RENAMES F1;
   
          FUNCTION "*" (X, Y : INTEGER) RETURN CITRUS
               RENAMES F1;
      
          I1 : CONSTANT INTEGER := F1 (0, 0);
          W1 : CONSTANT WHOLE   := F1 (0, 0);
          C1 : CONSTANT CITRUS  := F1 (0, 0);
          H1 : CONSTANT HUE     := F1 (0, 0);
   
          I2 : CONSTANT INTEGER := "*" (0, 0);
          W2 : CONSTANT WHOLE   := "*" (0, 0);
          C2 : CONSTANT CITRUS  := "*" (0, 0);
          H2 : CONSTANT HUE     := "*" (0, 0);
      
          I3 : CONSTANT INTEGER := (0 * 0);
          W3 : CONSTANT WHOLE   := (0 * 0);
          C3 : CONSTANT CITRUS  := (0 * 0);
          H3 : CONSTANT HUE     := (0 * 0);
      
          C4 : CONSTANT CITRUS  := ORANGE;
          H4 : CONSTANT HUE     := ORANGE;

     BEGIN
          IF I1              /= -1 OR W1           /= 0 OR
             CITRUS'POS (C1) /=  2 OR HUE'POS (H1) /= 1 THEN
             FAILED ("(A): RESOLUTION INCORRECT - FUNCTION CALL");
          END IF;
    
          IF I2              /= -1 OR W2           /= 0 OR
             CITRUS'POS (C2) /=  2 OR HUE'POS (H2) /= 1 THEN
             FAILED ("(B): RESOLUTION INCORRECT - OPERATOR SYMBOL");
          END IF;
    
          IF I3              /= -1 OR W3           /= 0 OR
             CITRUS'POS (C3) /=  2 OR HUE'POS (H3) /= 1 THEN
             FAILED ("(C): RESOLUTION INCORRECT - INFIX OPERATOR");
          END IF;
    
          IF CITRUS'POS (C4) /=  2 OR HUE'POS (H4) /= 1 THEN
             FAILED ("(D): RESOLUTION INCORRECT - ENUMERATION LITERAL");
          END IF;
     END;
    
     RESULT;
END C87B02A;
