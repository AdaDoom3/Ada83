-- CE3106A.ADA

-- OBJECTIVE:
--     CHECK THAT CLOSING A FILE HAS THE FOLLOWING EFFECT:
--          1) IF THERE IS NO LINE TERMINATOR, A LINE TERMINATOR, PAGE
--             TERMINATOR, AND FILE TERMINATOR ARE WRITTEN AT THE END
--             OF THE FILE.
--          2) IF THERE IS A LINE TERMINATOR BUT NO PAGE TERMINATOR, A
--             PAGE TERMINATOR AND A FILE TERMINATOR ARE WRITTEN.
--          3) IF THERE IS A PAGE TERMINATOR, A FILE TERMINATOR IS
--             WRITTEN.

-- APPLICABILITY CRITERIA:
--     THIS TEST IS APPLICABLE ONLY TO IMPLEMENTATIONS WHICH SUPPORT
--     TEXT FILES.

-- HISTORY:
--     JLH 07/08/88  CREATED ORIGINAL TEST.

WITH REPORT; USE REPORT;
WITH TEXT_IO; USE TEXT_IO;

PROCEDURE CE3106A IS

     INCOMPLETE : EXCEPTION;
     FILE1, FILE2, FILE3 : FILE_TYPE;
     ITEM : CHARACTER;

BEGIN

     TEST ("CE3106A", "CHECK THAT CLOSING A FILE HAS THE CORRECT " &
                      "EFFECT ON THE FILE CONCERNING LINE, PAGE, " &
                      "AND FILE TERMINATORS");

     BEGIN

          BEGIN
               CREATE (FILE1, OUT_FILE, LEGAL_FILE_NAME);
          EXCEPTION
               WHEN USE_ERROR =>
                    NOT_APPLICABLE ("USE_ERROR RAISED ON CREATE " &
                                    "WITH MODE OUT_FILE");
                    RAISE INCOMPLETE;
               WHEN NAME_ERROR =>
                    NOT_APPLICABLE ("NAME_ERROR RAISED ON CREATE" &
                                    "WITH MODE OUT_FILE");
                    RAISE INCOMPLETE;
               WHEN OTHERS =>
                    FAILED ("UNEXPECTED EXCEPTION RAISED ON CREATE");
                    RAISE INCOMPLETE;
          END;

          PUT (FILE1, 'A');
          NEW_LINE (FILE1);
          PUT (FILE1, 'B');

          CLOSE (FILE1);

          BEGIN
               OPEN (FILE1, IN_FILE, LEGAL_FILE_NAME);
          EXCEPTION
               WHEN USE_ERROR =>
                    NOT_APPLICABLE ("USE_ERROR RAISED ON TEXT OPEN " &
                                    "WITH MODE IN_FILE");
                    RAISE INCOMPLETE;
          END;

          GET (FILE1, ITEM);

          IF LINE (FILE1) /= 1 THEN
               FAILED ("INCORRECT LINE NUMBER - 1");
          END IF;

          GET (FILE1, ITEM);
          IF ITEM /= 'B' THEN
               FAILED ("INCORRECT VALUE READ - 1");
          END IF;

          IF LINE (FILE1) /= 2 THEN
               FAILED ("INCORRECT LINE NUMBER - 2");
          END IF;

          IF NOT END_OF_LINE (FILE1) THEN
               FAILED ("LINE TERMINATOR NOT WRITTEN WHEN FILE " &
                       "IS CLOSED");
          END IF;

          IF NOT END_OF_PAGE (FILE1) THEN
               FAILED ("PAGE TERMINATOR NOT WRITTEN WHEN FILE " &
                       "IS CLOSED");
          END IF;

          IF NOT END_OF_FILE (FILE1) THEN
               FAILED ("FILE TERMINATOR NOT WRITTEN WHEN FILE " &
                       "IS CLOSED");
          END IF;

          BEGIN
               DELETE (FILE1);
          EXCEPTION
               WHEN USE_ERROR =>
                    NULL;
          END;

          CREATE (FILE2, OUT_FILE, LEGAL_FILE_NAME(2));
          PUT (FILE2, 'A');
          NEW_LINE (FILE2);
          PUT (FILE2, 'B');
          NEW_PAGE (FILE2);
          PUT (FILE2, 'C');
          NEW_LINE (FILE2);

          CLOSE (FILE2);

          OPEN (FILE2, IN_FILE, LEGAL_FILE_NAME(2));

          GET (FILE2, ITEM);

          GET (FILE2, ITEM);
          IF ITEM /= 'B' THEN
               FAILED ("INCORRECT VALUE READ - 2");
          END IF;

          IF LINE (FILE2) /= 2 THEN
               FAILED ("INCORRECT LINE NUMBER - 3");
          END IF;

          GET (FILE2, ITEM);

          IF LINE (FILE2) /= 1 THEN
               FAILED ("INCORRECT LINE NUMBER - 4");
          END IF;

          IF PAGE (FILE2) /= 2 THEN
               FAILED ("INCORRECT PAGE NUMBER - 1");
          END IF;

          IF NOT END_OF_PAGE (FILE2) THEN
               FAILED ("PAGE TERMINATOR NOT WRITTEN WHEN FILE " &
                       "IS CLOSED - 2");
          END IF;

          IF NOT END_OF_FILE (FILE2) THEN
               FAILED ("FILE TERMINATOR NOT WRITTEN WHEN FILE " &
                       "IS CLOSED - 2");
          END IF;

          BEGIN
               DELETE (FILE2);
          EXCEPTION
               WHEN USE_ERROR =>
                    NULL;
          END;

          CREATE (FILE3, OUT_FILE, LEGAL_FILE_NAME(3));
          PUT (FILE3, 'A');
          NEW_PAGE (FILE3);
          PUT (FILE3, 'B');
          NEW_PAGE (FILE3);
          NEW_LINE (FILE3);
          PUT (FILE3, 'C');
          NEW_PAGE (FILE3);

          CLOSE (FILE3);

          OPEN (FILE3, IN_FILE, LEGAL_FILE_NAME(3));

          GET (FILE3, ITEM);

          GET (FILE3, ITEM);
          IF ITEM /= 'B' THEN
               FAILED ("INCORRECT VALUE READ - 3");
          END IF;

          GET (FILE3, ITEM);

          IF LINE (FILE3) /= 2 THEN
               FAILED ("INCORRECT LINE NUMBER - 5");
          END IF;

          IF PAGE (FILE3) /= 3 THEN
               FAILED ("INCORRECT PAGE NUMBER - 2");
          END IF;

          IF NOT END_OF_FILE (FILE3) THEN
               FAILED ("FILE TERMINATOR NOT WRITTEN WHEN FILE " &
                       "IS CLOSED - 3");
          END IF;

          BEGIN
               DELETE (FILE3);
          EXCEPTION
               WHEN USE_ERROR =>
                    NULL;
          END;

     EXCEPTION
          WHEN INCOMPLETE =>
               NULL;
     END;

     RESULT;

END CE3106A;
