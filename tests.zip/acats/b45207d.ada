-- B45207D.ADA


-- CHECK THAT EQUALITY AND INEQUALITY ARE NOT PREDEFINED FOR LIMITED
--     TYPES.


-- PART 1: LIMITED TYPES NOT INVOLVING TASKING OR TYPE DERIVATION.


-- CASES COVERED:              ( ">>" MARKS CASES COVERED IN THIS FILE.)

--    * LIMITED PRIVATE TYPE
--    * ARRAY WHOSE COMPONENTS ARE OF A LIMITED PRIVATE TYPE
--    * RECORD WITH A COMPONENT WHICH IS OF A LIMITED PRIVATE TYPE
--    * ARRAY OF LIMITED-TYPE RECORDS (AS ABOVE)
--    * RECORDS OF LIMITED-TYPE ARRAYS  (AS ABOVE)
-->>  * ARRAY WHOSE COMPONENTS ARE OF AN EQUALITY-ENDOWED
--          LIMITED PRIVATE TYPE
-->>  * RECORD ALL OF WHOSE COMPONENTS ARE OF AN EQUALITY-ENDOWED
--          LIMITED PRIVATE TYPE


-- RM  2/12/82
-- RM  2/22/82


PROCEDURE B45207D IS

BEGIN


     -------------------------------------------------------------------
     -------  ARRAY OF EQUALITY-ENDOWED LIMITED-TYPE COMPONENTS  -------
                            
     DECLARE

          B      : BOOLEAN := TRUE ;

          TYPE  ENUM  IS  ( AA , BB , CC );

          PACKAGE  P  IS
               TYPE  LP  IS  LIMITED PRIVATE;
               FUNCTION "=" ( U,V:LP ) RETURN BOOLEAN ;
          PRIVATE
               TYPE  LP  IS  NEW ENUM ;
          END  P ;

          USE  P ;

          TYPE  ARR  IS  ARRAY ( 1..3 ) OF  LP ;

          X , Y : ARR ;

          PACKAGE BODY  P  IS
               FUNCTION "=" ( U,V:LP ) RETURN BOOLEAN IS
               BEGIN
                    RETURN ( ENUM(U) = ENUM(V) );
               END "=" ;
          BEGIN

               X(1) := AA ;
               X(2) := AA ;
               X(3) := AA ;
               Y(1) := AA ;
               Y(2) := AA ;
               Y(3) := AA ;

               IF  X = Y                -- ERROR: EQUALITY NOT AVAILABLE
               THEN
                    NULL ;
               END IF;

          END  P ;

     BEGIN

          IF  X = Y               -- ERROR: EQUALITY STILL NOT AVAILABLE
          THEN
               NULL ;
          END IF;

          B := ( X /= Y ) ;       -- ERROR: EQUALITY STILL NOT AVAILABLE

     END ;


     -------------------------------------------------------------------
     -------  RECORD OF EQUALITY-ENDOWED LIMITED-TYPE COMPONENTS  ------
                         
     DECLARE

          B      : BOOLEAN := TRUE ;

          TYPE  ENUM  IS  ( AA , BB , CC );

          PACKAGE  P  IS
               TYPE  LP  IS  LIMITED PRIVATE;
               FUNCTION "=" ( U,V:LP ) RETURN BOOLEAN ;
          PRIVATE
               TYPE  LP  IS  NEW ENUM ;
          END  P ;

          USE  P ;

          TYPE  REC  IS
               RECORD
                    COMPONENT1 : LP ;
                    COMPONENT2 : LP ;
               END RECORD;

          X , Y : REC ;

          PACKAGE BODY  P  IS
               FUNCTION "=" ( U,V:LP ) RETURN BOOLEAN IS
               BEGIN
                    RETURN ( ENUM(U) = ENUM(V) );
               END "=" ;
          BEGIN

               X.COMPONENT1 := AA ;
               X.COMPONENT2 := AA ;
               Y.COMPONENT1 := AA ;
               Y.COMPONENT2 := AA ;

               IF  X = Y                -- ERROR: EQUALITY NOT AVAILABLE
               THEN
                    NULL ;
               END IF;

          END  P ;

     BEGIN

          IF  X = Y               -- ERROR: EQUALITY STILL NOT AVAILABLE
          THEN
               NULL ;
          END IF;

          B := ( X /= Y ) ;       -- ERROR: EQUALITY STILL NOT AVAILABLE

     END ;


     -------------------------------------------------------------------


END B45207D ;
