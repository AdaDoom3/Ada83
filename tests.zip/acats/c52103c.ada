-- C52103C.ADA


-- CHECK THAT LENGTHS MUST MATCH IN ARRAY AND SLICE ASSIGNMENTS.
--    MORE SPECIFICALLY, TEST THAT ARRAY ASSIGNMENTS WITH MATCHING
--    LENGTHS DO NOT CAUSE  CONSTRAINT_ERROR  TO BE RAISED AND
--    ARE PERFORMED CORRECTLY.
--    (OVERLAPS BETWEEN THE OPERANDS OF THE ASSIGNMENT STATEMENT
--    ARE TREATED ELSEWHERE.)

-- THIS IS THE THIRD FILE IN
--    DIVISION  A : STATICALLY-DETERMINABLE NON-NULL LENGTHS.


-- RM 07/20/81
-- SPS 3/22/83


WITH REPORT;


PROCEDURE  C52103C  IS

     USE  REPORT ;

BEGIN

     TEST( "C52103C" , "CHECK THAT IN ARRAY ASSIGNMENTS AND IN SLICE" &
                       " ASSIGNMENTS  THE LENGTHS MUST MATCH" );


     --                              ( EACH DIVISION COMPRISES 3 FILES,
     --                                COVERING RESPECTIVELY THE FIRST
     --                                3 , NEXT 2 , AND LAST 3 OF THE 8
     --                                SELECTIONS FOR THE DIVISION.)


     -------------------------------------------------------------------

     --    (7) UNSLICED OBJECTS OF THE PREDEFINED TYPE  'STRING'  (BY
     --        THEMSELVES).

     DECLARE

          ARR71  :  STRING( 1..5 )  := "ABCDE" ;
          ARR72  :  STRING( 5..9 )  := "FGHIJ" ;

     BEGIN


          -- STRING ASSIGNMENT:

          ARR72 := ARR71 ;


          -- CHECKING THE VALUES AFTER THE STRING ASSIGNMENT:

          IF  ARR72 /= "ABCDE"
          THEN
               FAILED( "STRING ASSIGNMENT NOT CORRECT (7)" );
          END IF;

     EXCEPTION

          WHEN  OTHERS  =>
               FAILED( "EXCEPTION RAISED  -  SUBTEST 7" );

     END ;


     -------------------------------------------------------------------

     --    (8) SLICED OBJECTS OF THE PREDEFINED TYPE  'STRING' , WITH
     --        STRING LITERALS.
     --

     DECLARE

          ARR82 : STRING( 5..9 ) ;

     BEGIN


          -- INITIALIZATION OF UNUSED COMPONENT OF LHS ARRAY:

          ARR82( 5..5 )  :=  "Q"  ;


          -- STRING LITERAL ASSIGNMENT:

          ARR82( 5..9 )( 6..9 ) :=  "BCDE" ;


          -- CHECKING THE VALUES AFTER THE SLICE ASSIGNMENT:

          IF  ARR82           /=  "QBCDE"  OR
              ARR82(  5..9  ) /=  "QBCDE"
          THEN
               FAILED( "SLICE ASSIGNMENT NOT CORRECT (8)" );
          END IF;

     EXCEPTION

          WHEN  OTHERS  =>
               FAILED( "EXCEPTION RAISED  -  SUBTEST 8" );

     END ;

     -------------------------------------------------------------------

     --    (9) SLICED OBJECTS OF THE PREDEFINED TYPE  'STRING'  (BY
     --        THEMSELVES).
     --

     DECLARE

          SUBTYPE  TA92  IS  STRING( 5..9 ) ;

          ARR91  :  STRING( 1..5 )  := "ABCDE" ;
          ARR92  :  TA92 ;

     BEGIN


          -- INITIALIZATION OF UNUSED COMPONENT OF LHS ARRAY:

          ARR92( 5..5 )  :=  "Q"  ;


          -- STRING SLICE ASSIGNMENT:

          ARR92( 5..9 )( 6..9 ) :=  ARR91( 1..5 )(2..5 )( 2..5 ) ;


          -- CHECKING THE VALUES AFTER THE SLICE ASSIGNMENT:

          IF  ARR92           /=  "QBCDE"  OR
              ARR92(  5..9  ) /=  "QBCDE"
          THEN
               FAILED( "SLICE ASSIGNMENT NOT CORRECT (9)" );
          END IF;

     EXCEPTION

          WHEN  OTHERS  =>
               FAILED( "EXCEPTION RAISED  -  SUBTEST 9" );

     END ;


     -------------------------------------------------------------------


     RESULT ;


END C52103C;
